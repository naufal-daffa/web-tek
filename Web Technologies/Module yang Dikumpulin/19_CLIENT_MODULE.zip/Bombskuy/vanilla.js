let playGameBtn = document.getElementById("playGameBtn");
let usernameInput = document.getElementById("usernameInput");
let instModal = document.getElementById("instModal");
let instBtn = document.getElementById("instBtn");
let closeInstBtn = document.getElementById("closeInstBtn");
let gameContainer = document.getElementById("gameContainer");
let menuContainer = document.getElementById("menuContainer");
let continueBtn = document.getElementById("continueBtn");
let pauseModal = document.getElementById("pauseModal");
let gameOverModal = document.getElementById("gameOverModal");

let backgroundImg = new Image();
backgroundImg.src = "Images/background.jpg";

let playerImg = new Image();
playerImg.src = "Images/char_down.png"

let dogImg = new Image();
dogImg.src = "Images/dog_down.png";

let wallImg = new Image();
wallImg.src = "Images/wall.png";

let bombImg = new Image();
bombImg.src = "Images/bomb.png"

let canvas = document.getElementById("canvas");
let ctx = canvas.getContext('2d');
backgroundImg.height = canvas.height;

let gridH = canvas.height / 9
let gridW = gridH;

wallImg.style.width = gridW;
wallImg.style.height = gridH;

let rows = 11;
let cols = 9;

let grids = []
let stones = [];
let walls = [];

let bombPlaced = false;
let bombPosition = { x: 0, y: 0 };
let bombTimeout;
let bombRadiusX = 1;
let bombRadiusY = 1;
let exploding = false;
let explosions;

let playerPosition = { x: 1, y: 1 };

let dog1position = { x: 0, y: 0 };
let dog2position = { x: 0, y: 0 };
let dog3position = { x: 0, y: 0 };
let gamePaused = false;
let timerInterval;
let timer = 0;

let health = 3;
let wallBroken = 0;

let middleStones = [];
let gameStarted = false;

usernameInput.addEventListener("input", () => {
    if (usernameInput.value.length > 0) {
        playGameBtn.removeAttribute("disabled");
    } else {
        playGameBtn.addAttribute("disabled", true)
    }
})

playGameBtn.addEventListener("click", () => {
    menuContainer.classList.add("hidden")
    gameContainer.classList.remove("hidden")
    initializeGame();
});

instBtn.addEventListener("click", () => {
    instModal.classList.remove('hidden');
});

closeInstBtn.addEventListener("click", () => {
    instModal.classList.add("hidden");
});

document.addEventListener("keydown", (e) => {
    if (checkPlayerPosition(e.key) || !gameStarted || gamePaused) return;

    if (e.key == 'd') playerImg.src = 'Images/char_right.png', playerPosition.x += 1;
    if (e.key == 'a') playerImg.src = 'Images/char_left.png', playerPosition.x -= 1;
    if (e.key == 's') playerImg.src = 'Images/char_down.png', playerPosition.y += 1;
    if (e.key == 'w') playerImg.src = 'Images/char_up.png', playerPosition.y -= 1;
    if (e.key == ' ' && !bombPlaced) {
        placeBomb();
        setTimeout(() => {
            bombPlaced = false;
            bombExplode();
            draw()
        }, 5000);
    };
    if (e.key == 'Escape') {
        if (!gamePaused) {
            pauseGame()
        } else {
            continueGame();
        }
    };

    checkPlayerHit();
    playerImg.onload = function () {
        draw();
    }
})

continueBtn.addEventListener("click", () => {
    continueGame();
})

if (backgroundImg.complete) {
    initializeGame()
} else {
    backgroundImg.onload = function () {
        initializeGame();
    }
}

function pauseGame() {
    pauseModal.classList.remove("hidden");
    gamePaused = true;
    clearInterval(timerInterval);
}

function continueGame() {
    pauseModal.classList.add("hidden");
    gamePaused = false;
    startTimer();
}

function initializeGame() {
    clearInterval(timerInterval);
    gridH = canvas.height / 9
    gridW = gridH;

    rows = 11;
    cols = 9;

    grids = []
    stones = [];
    walls = [];

    bombPlaced = false;
    bombPosition = { x: 0, y: 0 };
    bombTimeout;
    bombRadiusX = 1;
    bombRadiusY = 1;
    exploding = false;
    explosions;

    playerPosition = { x: 1, y: 1 };

    dog1position = { x: 0, y: 0 };
    dog2position = { x: 0, y: 0 };
    dog3position = { x: 0, y: 0 };
    gamePaused = false;
    timerInterval;
    timer = 0;

    health = 3;

    middleStones = [];

    generateGrid();
    generateStoneBorder();
    generateStone();
    generateWall();
    generateDogPosition();
    startTimer();
    draw();

    gameStarted = true;
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    drawBackground();
    drawWall();

    if (exploding) {
        drawExplosion();
    }
    drawPlayer();
    if (bombPlaced) {
        drawBomb();
    }
    drawDog();
    drawHealth();
    drawTimer();
    drawWallBroken();
}

function drawHealth() {
    ctx.font = "24px Arial";
    ctx.fillStyle = "white";
    ctx.textAlign = "right";
    ctx.fillText(`Health: ${health}`, canvas.width - 20, 170);
}

function drawWallBroken() {
    ctx.font = "24px Arial";
    ctx.fillStyle = "white";
    ctx.textAlign = "right";
    ctx.fillText(`Wall Broken: ${wallBroken}`, canvas.width - 20, 70);
}

function drawTimer() {
    ctx.font = "24px Arial";
    ctx.fillStyle = "white";
    ctx.textAlign = "right";
    ctx.fillText(`Time: ${timer} secs`, canvas.width - 20, 120);
}

function drawBackground() {
    ctx.drawImage(backgroundImg, 5, 5);
}

function drawExplosion() {
    ctx.fillStyle = "rgba(255, 0, 0, 0.5)"
    explosions.forEach((val) => {
        let drawX = val.x * gridW
        let drawY = val.y * gridH

        let onStone = stones.some(value => {
            return val.x === value.x && val.y === value.y;
        })

        if (!onStone) {
            ctx.fillRect(drawX, drawY, gridW, gridH)
        }
    })
}

function drawWall() {
    walls.forEach((wall) => {
        let drawX = wall.x * gridW
        let drawY = wall.y * gridH
        ctx.drawImage(wallImg, drawX, drawY)
    })
}

function drawPlayer() {
    let drawX = playerPosition.x * gridW
    let drawY = playerPosition.y * gridH
    ctx.drawImage(playerImg, drawX, drawY)
}

function startTimer() {
    timerInterval = setInterval(() => {
        timer++
        draw();
    }, 1000);
}

function checkPlayerPosition(key) {
    let playerNextMoveX = 0
    let playerNextMoveY = 0

    if (key == 'd') playerNextMoveX += 1;
    if (key == 'a') playerNextMoveX -= 1;
    if (key == 's') playerNextMoveY += 1;
    if (key == 'w') playerNextMoveY -= 1;

    let isStone = false;
    stones.forEach((value) => {
        if (playerPosition.x + playerNextMoveX == value.x && playerPosition.y + playerNextMoveY == value.y) {
            isStone = true
        }
    });

    walls.forEach((value) => {
        if (playerPosition.x + playerNextMoveX == value.x && playerPosition.y + playerNextMoveY == value.y) {
            isStone = true
        }
    })

    return isStone;
}

function checkPlayerHit() {
    if (playerPosition.x === dog1position.x && playerPosition.y === dog1position.y) {
        health--;
        if (health == 0) {
            gameStarted = false;
            clearInterval(timerInterval);
            gameOverModal.classList.remove("hidden")
        }
    }
}

function minusHealth() {
    health--
    initializeGame();
}

function generateGrid() {
    for (let i = 0; i < rows; i++) {
        for (let j = 0; j < cols; j++) {
            grids.push({
                x: i,
                y: j,
            })
        }
    }
}

function drawBomb() {
    let drawX = bombPosition.x * gridW;
    let drawY = bombPosition.y * gridH;
    ctx.drawImage(bombImg, drawX, drawY);
}

function bombExplode() {
    exploding = true;
    explosions = [
        {
            x: bombPosition.x + bombRadiusX,
            y: bombPosition.y,
        },
        {
            x: bombPosition.x - bombRadiusX,
            y: bombPosition.y,
        },
        {
            x: bombPosition.x,
            y: bombPosition.y + bombRadiusY,
        },
        {
            x: bombPosition.x,
            y: bombPosition.y - bombRadiusY,
        },
        {
            x: bombPosition.x,
            y: bombPosition.y,
        },
    ]

    walls.forEach((wall, index) => {
        let isBreakWall = explosions.some((exp) => {
            return exp.x === wall.x && exp.y === wall.y
        })

        if (isBreakWall) {
            wallBroken++;
            walls.splice(index, 1);
            draw();
        }
    });

    setTimeout(() => {
        exploding = false;
        draw();
    }, 500);
}

function drawDog() {
    let drawX = dog1position.x * gridH;
    let drawY = dog1position.y * gridW;
    ctx.drawImage(dogImg, drawX, drawY);
}

function generateDogPosition() {
    let randomX = Math.abs(Math.floor(Math.random() * 10 - 4));
    let randomY = Math.abs(Math.floor(Math.random() * 10 - 4));

    let onStone = stones.some(value => {
        return randomX === value.x && randomY === value.y;
    })

    if (onStone) {
        randomX += 1;
        randomY += 1;
    }

    dog1position.x = randomX
    dog1position.y = randomY
}

function placeBomb() {
    if (bombPlaced) return;

    bombPosition.x = playerPosition.x;
    bombPosition.y = playerPosition.y;
    bombPlaced = true;
}

function generateWall() {
    grids.forEach((grid) => {
        let randomNum = Math.random();
        if (grid.x != 0 && grid.y != 0) {
            if (grid.x < 10 && grid.y < 8) {
                let isStone = stones.some((stone) => {
                    return grid.x === stone.x && grid.y === stone.y
                })

                if (randomNum < 0.5) {
                    if (!isStone) {
                        walls.push(grid);
                    }
                }
            }
        }
    });

    let wallPlayerIndex = walls.findIndex(value => {
        return value.x == playerPosition.x && value.y == playerPosition.y;
    })

    walls.splice(wallPlayerIndex, 1);
}

function generateStone() {
    for (let i = 0; i < rows; i++) {
        for (let j = 0; j < cols; j++) {
            if (i % 2 == 0) {
                if (j % 2 == 0) {
                    stones.push({
                        x: i,
                        y: j,
                    });
                }
            }
        }
    }

}

function generateStoneBorder() {
    for (let i = 0; i <= rows; i++) {
        stones.push({
            x: i,
            y: 0,
        });
    }

    for (let j = 0; j <= cols; j++) {
        stones.push({
            x: 0,
            y: j,
        });
    }
}