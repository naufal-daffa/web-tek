import { createRouter, createWebHistory } from 'vue-router'
import LoginView from '@/views/LoginView.vue'
import DashboardView from '@/views/DashboardView.vue'
import ValidationFormView from '@/views/ValidationFormView.vue'
import InstalmentCarsListView from '@/views/InstalmentCarsListView.vue'
import InstalmentCarDetailView from '@/views/InstalmentCarDetailView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'login',
      component: LoginView,
    },
    {
      path: '/dashboard',
      name: 'dashboard',
      component: DashboardView,
      meta: {reqAuth: true},
    },
    {
      path: '/create-validation',
      name: 'createValidation',
      component: ValidationFormView,
      meta: {reqAuth: true},
    },
    {
      path: '/instalment-cars-list',
      name: 'instalmentCarsList',
      component: InstalmentCarsListView,
      meta: {reqAuth: true},
    },
    {
      path: '/instalment-detail/:id',
      name: 'instalmentDetail',
      component: InstalmentCarDetailView,
      meta: {reqAuth: true},
    },
  ],
})

router.beforeEach((to, from, next) => {
  const token = localStorage.getItem("token")

  if (to.meta.reqAuth) {
    if (!token) {
      return next({path: '/'})
    }
  }

  return next();
});

export default router
