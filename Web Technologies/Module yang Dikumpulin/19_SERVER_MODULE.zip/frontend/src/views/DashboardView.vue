<template>
    <Navbar />

    <main>
        <!-- S: Header -->
        <header class="jumbotron">
            <div class="container text-center">
                <h1 class="display-4">Installment Cars</h1>
            </div>
        </header>
        <!-- E: Header -->

        <div class="container">

            <!-- S: Data Validation Section -->
            <section class="validation-section mb-5">
                <div class="alert alert-success" v-if="validationRequestMessage">
                    Request data validation successful
                </div>
                <div class="section-header mb-3">
                    <h4 class="section-title text-muted">My Data Validation</h4>
                </div>
                <div class="row">

                    <!-- S: Link to Request Data Validation -->
                    <div class="col-md-4" v-if="validation.length == 0">
                        <div class="card card-default">
                            <div class="card-header">
                                <h5 class="mb-0">Data Validation</h5>
                            </div>
                            <div class="card-body">
                                <router-link to="/create-validation" class="btn btn-primary btn-block">+ Request
                                    validation</router-link>
                            </div>
                        </div>
                    </div>
                    <!-- E: Link to Request Data Validation -->

                    <!-- S: Society Data Validation Box (Pending) -->
                    <div class="col-md-4" v-else>
                        <div class="card card-default">
                            <div class="card-header border-0">
                                <h5 class="mb-0">Data Validation</h5>
                            </div>
                            <div class="card-body p-0">
                                <table class="table table-striped mb-0">
                                    <tr>
                                        <th>Status</th>
                                        <td><span class="badge badge-success">{{ validation?.status }}</span></td>
                                    </tr>
                                    <tr>
                                        <th>Job</th>
                                        <td class="text-muted">{{ validation?.job }}</td>
                                    </tr>
                                    <tr>
                                        <th>Income/Month</th>
                                        <td class="text-muted">Rp. {{ validation?.income }}</td>
                                    </tr>
                                    <tr>
                                        <th>Validator</th>
                                        <td class="text-muted">{{ validation.validator?.name }}</td>
                                    </tr>
                                    <tr>
                                        <th>Validator Notes</th>
                                        <td class="text-muted">-</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!-- E: Society Data Validation Box (Pending) -->

                </div>
            </section>
            <!-- E: Data Validation Section -->

            <!-- S: List Job Seekers Section -->
            <section class="validation-section mb-5">
                <div class="section-header mb-3">
                    <div class="row">
                        <div class="col-md-8">
                            <h4 class="section-title text-muted">My Instalment Cars</h4>
                        </div>
                        <div class="col-md-4">
                            <router-link to="/instalment-cars-list" class="btn btn-primary btn-lg btn-block">+ Add Installment
                                Cars</router-link>
                        </div>
                    </div>
                </div>
                <div class="section-body">
                    <div class="row mb-4">

                        <!-- S: Installment Cars info -->
                        <div class="col-md-12">
                            <div class="alert alert-warning" v-if="validation.status != 'accepted'">
                                Your validation must be approved by validator to Installment Cars.
                            </div>
                        </div>
                        <!-- E: Installment Cars info -->

                        <!-- S: Installment Cars Box (Registered) -->
                        <div class="col-md-6" v-for="instalementCar in instalementCars">
                            <div class="card card-default">
                                <div class="card-header border-0">
                                    <h5 class="mb-0">{{ instalementCar?.car }}</h5>
                                </div>
                                <div class="card-body p-0">
                                    <table class="table table-striped mb-0">
                                        <tr>
                                            <th>Description</th>
                                            <td class="text-muted">{{ instalementCar?.description }}</td>
                                        </tr>
                                        <tr>
                                            <th>Price</th>
                                            <td class="text-muted">Rp. {{ instalementCar?.price }}</td>
                                        </tr>
                                        <tr>
                                            <th>Installment</th>
                                            <td class="text-muted">
                                                {{ instalementCar?.applications?.[0]?.month }} Months <span
                                                    class="badge badge-info">{{
                                                        instalementCar?.applications?.[0]?.apply_status }}</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Apply Date</th>
                                            <td class="text-muted">-</td>
                                        </tr>
                                        <tr>
                                            <th>Notes</th>
                                            <td class="text-muted">{{ instalementCar?.applications?.[0]?.notes }}</td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- S: Installment Cars Box (Registered) -->
                        <!-- S: Installment Cars Box (Registered) -->
                        <!-- <div class="col-md-6">
                            <div class="card card-default">
                                <div class="card-header border-0">
                                    <h5 class="mb-0">Nissan Livina</h5>
                                </div>
                                <div class="card-body p-0">
                                    <table class="table table-striped mb-0">
                                        <tr>
                                            <th>Description</th>
                                            <td class="text-muted">Family Cars for everyone</td>
                                        </tr>
                                        <tr>
                                            <th>Price</th>
                                            <td class="text-muted">Rp. 275.000.000</td>
                                        </tr>
                                        <tr>
                                            <th>Installment</th>
                                            <td class="text-muted">
                                                24 Months <span class="badge badge-success">Accepted</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Apply Date</th>
                                            <td class="text-muted">Desember 12, 2024</td>
                                        </tr>
                                        <tr>
                                            <th>Notes</th>
                                            <td class="text-muted">I want this one too.</td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div> -->
                        <!-- S: Installment Cars Box (Registered) -->

                    </div>
                </div>
            </section>
            <!-- E: List Job Seekers Section -->

        </div>
    </main>
    <!-- S: Footer -->
    <footer>
        <div class="container">
            <div class="text-center py-4 text-muted">
                Copyright &copy; 2025 - LKSP Jabar Web Technologies
            </div>
        </div>
    </footer>
    <!-- E: Footer -->
</template>

<script>
import axios from 'axios';
import { API_URL } from '@/constant.js';
import Navbar from '@/components/Navbar.vue';

export default {
    components: {
        Navbar,
    },
    data() {
        return {
            validation: [],
            instalementCars: [],
            validationRequestMessage: false,
        }
    },
    methods: {
        async getValidation() {
            try {
                const token = localStorage.getItem("token");
                const response = await axios.get(API_URL + '/validations', {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    }
                });

                this.validation = response.data.validation;
            } catch (err) {

            }
        },
        async getCars() {
            try {
                const token = localStorage.getItem("token");
                const response = await axios.get(API_URL + '/applications', {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    }
                });

                this.instalementCars = response.data.instalments;
            } catch (err) {

            }
        },
        checkValidationRequestMessage() {
            const message = localStorage.getItem("requestDataMessage");

            if (parseInt(message)) {
                this.validationRequestMessage = true
            }

            localStorage.removeItem("requestDataMessage");
        }
    },
    mounted() {
        this.getValidation();
        this.getCars();
        this.checkValidationRequestMessage();
    }
}
</script>