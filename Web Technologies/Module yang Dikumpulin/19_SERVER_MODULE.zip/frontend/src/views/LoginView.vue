<template>

  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-primary">
    <div class="container">
      <a class="navbar-brand" href="#">Installment Cars</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault"
        aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="#">Login</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <main>
    <!-- S: Header -->
    <header class="jumbotron">
      <div class="container text-center">
        <h1 class="display-4">Installment Cars</h1>
      </div>
    </header>
    <!-- E: Header -->

    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-6">
          <form class="card card-default" @submit.prevent="submitLogin">
            <div class="card-header">
              <h4 class="mb-0">Login</h4>
            </div>
            <div class="card-body">
              <div class="form-group row align-items-center">
                <div class="col-4 text-right">ID Card Number</div>
                <div class="col-8"><input type="text" class="form-control" v-model="idCard"></div>
              </div>
              <div class="form-group row align-items-center">
                <div class="col-4 text-right">Password</div>
                <div class="col-8"><input type="password" class="form-control" v-model="password"></div>
              </div>
              <div class="form-group row align-items-center mt-4">
                <div class="col-4"></div>
                <div class="col-8"><button class="btn btn-primary">Login</button></div>
              </div>
              <p v-if="wrongCred" class="text-danger">ID Card Number or Password
                incorrect</p>
              <p v-if="justLogout" class="text-success">logout success!</p>
            </div>
          </form>
        </div>
      </div>
    </div>
  </main>

  <!-- S: Footer -->
  <footer>
    <div class="container">
      <div class="text-center py-4 text-muted">
        Copyright &copy; 2025 - LKSP Jabar Web Technologies
      </div>
    </div>
  </footer>
  <!-- E: Footer -->
</template>

<script>
import axios from 'axios';
import { API_URL } from '@/constant.js';

export default {
  data() {
    return {
      idCard: '',
      password: '',
      wrongCred: false,
      justLogout: false,
    }
  },
  methods: {
    async submitLogin() {
      this.wrongCred = false;
      this.justLogout = false;
      try {
        const payload = {
          id_card_number: this.idCard,
          password: this.password
        }

        const response = await axios.post(API_URL + '/auth/login', payload);

        localStorage.setItem('token', response.data.token);
        localStorage.setItem('name', response.data.name);
        this.$router.push({ path: '/dashboard' })
      } catch (err) {
        this.wrongCred = true;
      }
    },
    justLogoutFunction() {
      const justLogout = localStorage.getItem("justLogout");

      if (parseInt(justLogout)) {
        this.justLogout = justLogout
      }

      localStorage.removeItem("justLogout");
    }
  },
  mounted() {
    this.justLogoutFunction();
  }
}

</script>