<template>
    <Navbar />

    <main>
        <!-- S: Header -->
        <header class="jumbotron">
            <div class="container text-center">
                <div>
                    <h1 class="display-4">{{ instalment.car }}</h1>
                    <span class="text-muted">Brand : {{ instalment.brand }}</span>
                </div>
            </div>
        </header>
        <!-- E: Header -->

        <div class="container">

            <div class="row mb-3">
                <div class="col-md-12">
                    <div class="form-group">
                        <h3>Description</h3>
                        {{ instalment.description }}
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <h3>Price : <span class="badge badge-primary">Rp. {{ instalment?.price }}</span></h3>
                    </div>
                </div>
            </div>

            <form @submit.prevent="applyInstalment">
                <div class="row mb-3">
                    <div class="col-md-12">
                        <div class="form-group">
                            <h3>Select Months</h3>
                            <select name="months" class="form-control" v-model="months">
                                <option :value="available_month.month"
                                    v-for="available_month in instalment?.available_month">{{
                                        available_month.description }}</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <h3>Nominal/Month : <span class="badge badge-primary">Rp. {{ instalment?.nominal }}</span>
                            </h3>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="d-flex align-items-center mb-3">
                                <label class="mr-3 mb-0">Notes</label>
                            </div>
                            <textarea class="form-control" cols="30" rows="6"
                                placeholder="Explain why your installment should be approved"
                                v-model="notes"></textarea>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="d-flex align-items-center mb-3">
                                <button class="btn btn-primary btn-lg" type="submit">Apply</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>


        </div>

        <div class="alert alert-success" v-if="successMessage">
            Applying for Instalment successful
        </div>

        <div class="alert alert-success" v-if="errorMessage">
            {{ errorNotif }}
        </div>
    </main>

    <!-- S: Footer -->
    <footer>
        <div class="container">
            <div class="text-center py-4 text-muted">
                Copyright &copy; 2025 - LKSP Jabar Web Technologies
            </div>
        </div>
    </footer>
    <!-- E: Footer -->
</template>

<script>
import axios from 'axios';
import { API_URL } from '@/constant.js';
import Navbar from '@/components/Navbar.vue';

export default {
    components: {
        Navbar,
    },
    data() {
        return {
            instalment: {},
            notes: '',
            months: '',
            successMessage: false,
            errorMessage: false,
            errorNotif: '',
        }
    },
    methods: {
        async getCarDetail() {
            try {
                const token = localStorage.getItem("token");
                const response = await axios.get(API_URL + "/instalment_cars/" + this.getCarId, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    }
                });

                this.instalment = response.data.instalment
            } catch (err) {
            }
        },
        async applyInstalment() {
            try {
                const token = localStorage.getItem("token");
                const response = await axios.post(API_URL + "/applications/", {
                    instalment_id: this.getCarId,
                    months: this.months,
                    notes: this.notes
                }, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    }
                });

                localStorage.setItem("successMessage", "1");
                this.checkMessage();
                setTimeout(() => {
                    this.$router.push({ path: '/dashboard' })
                }, 1500);
            } catch (err) {
                if (err.response.data.message == 'Invalid fields') {
                    this.errorNotif = 'Invalid fields'
                } else if(err.response.data.message == ' Application for a instalment can only be once') {
                    this.errorNotif = 'Application for a instalment can only be once'
                }

                localStorage.setItem("errorMessage", "1");
                this.checkMessage();
            }
        },
        checkMessage() {
            const success = localStorage.getItem("successMessage");
            const error = localStorage.getItem("error");

            if (parseInt(success)) {
                this.successMessage = true;
                localStorage.removeItem("successMessage");

            }

            if (parseInt(error)) {
                this.errorMessage = true;
                localStorage.removeItem("errorMessage");
            }
        }
    },
    mounted() {
        this.getCarDetail();
    },
    computed: {
        getCarId() {
            return this.$route.params.id;
        }
    }
}

</script>