<template>

    <Navbar />

    <main>
        <!-- S: Header -->
        <header class="jumbotron">
            <div class="container">
                <h1 class="display-4">Request Data Validation</h1>
            </div>
        </header>
        <!-- E: Header -->

        <div class="container">

            <form @submit.prevent="submitValidation">
                <div class="row mb-4">

                    <div class="col-md-6">
                        <div class="form-group">
                            <div class="d-flex align-items-center mb-3">
                                <label class="mr-3 mb-0">Are you working?</label>
                                <select class="form-control-sm">
                                    <option value="yes">Yes, I have</option>
                                    <option value="no">No</option>
                                </select>
                            </div>
                            <input type="text" placeholder="Your Job" class="form-control mt-2 mb-2" v-model="job">
                            <textarea class="form-control" cols="30" rows="5"
                                placeholder="describe what you do in your job" v-model="jobDescription"></textarea>
                            <input type="number" placeholder="Income (Rp)" class="form-control mt-2" v-model="income">
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="d-flex align-items-center mb-3">
                                <label class="mr-3 mb-0">Reason Accepted</label>
                            </div>
                            <textarea class="form-control" cols="30" rows="6"
                                placeholder="Explain why you should be accepted" v-model="reasonAccepted"></textarea>
                        </div>
                    </div>
                </div>

                <button class="btn btn-primary" type="submit">Send Request</button>
            </form>

        </div>

    </main>

    <!-- S: Footer -->
    <footer>
        <div class="container">
            <div class="text-center py-4 text-muted">
                Copyright &copy; 2025 - LKSP Jabar Web Technologies
            </div>
        </div>
    </footer>
    <!-- E: Footer -->
</template>

<script>
import Navbar from '@/components/Navbar.vue';
import axios from 'axios';
import { API_URL } from '@/constant.js';

export default {
    components: {
        Navbar,
    },
    data() {
        return {
            job: '',
            jobDescription: '',
            income: '',
            reasonAccepted: '',
        }
    },
    methods: {
        async submitValidation() {
            try {
                const token = localStorage.getItem("token");
                if (!token) {
                    this.$router.push({ path: '/' })
                }

                const response = await axios.post(API_URL + '/validation', {
                    job: this.job,
                    job_description: this.jobDescription,
                    income: this.income,
                    reason_accepted: this.reasonAccepted
                }, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    }
                });

                localStorage.setItem("requestDataMessage", "1");
                this.$router.push({ path: '/dashboard' })
            } catch (err) {

            }
        }
    }
}
</script>