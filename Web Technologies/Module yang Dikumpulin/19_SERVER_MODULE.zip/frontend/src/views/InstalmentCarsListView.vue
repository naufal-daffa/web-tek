<template>
    <Navbar />

    <main>
        <!-- S: Header -->
        <header class="jumbotron">
            <div class="container">
                <h1 class="display-4">Cars</h1>
            </div>
        </header>
        <!-- E: Header -->

        <div class="container mb-5">

            <div class="section-header mb-4">
                <h4 class="section-title text-muted font-weight-normal">List of Cars</h4>
            </div>

            <div class="section-body">

                <div v-for="car in cars">
                    <article :class="instalmentIds.includes(car.id) || car.available_month.length == 0 ? 'spot unavailable' : 'spot'">
                        <div class="row">
                            <div class="col-5">
                                <h5 class="text-primary">{{ car?.car }}</h5>
                                <span class="text-muted">{{ car?.description }}</span>
                            </div>
                            <div class="col-4">
                                <h5>Available Month</h5>
                                <span class="text-muted">
                                    <span v-for="available_month, index in car.available_month">
                                        {{ available_month.description }},
                                        <!-- <span v-if="index+1 != available_month.length">, </span> -->
                                    </span>
                                    <!-- 24 Months, 48 Months -->
                                </span>
                            </div>
                            <div class="col-3">
                                <div class="bg-success text-white p-2" v-if="instalmentIds.includes(car.id)">
                                    Instalment request have been submitted
                                </div>
                                <router-link :to="'/instalment-detail/' + car.id" class="btn btn-danger btn-lg btn-block" v-else>
                                    Detail
                                </router-link>
                            </div>
                        </div>
                    </article>
                </div>
            </div>

        </div>

    </main>

    <!-- S: Footer -->
    <footer>
        <div class="container">
            <div class="text-center py-4 text-muted">
                Copyright &copy; 2025 - LKSP Jabar Web Technologies
            </div>
        </div>
    </footer>
    <!-- E: Footer -->
</template>

<script>
import axios from 'axios';
import { API_URL } from '@/constant.js';
import Navbar from '@/components/Navbar.vue';

export default {
    components: {
        Navbar,
    },
    data() {
        return {
            cars: [],
            instalmentIds: [],
        }
    },
    methods: {
        async getAllInstalments() {
            const token = localStorage.getItem("token");
            try {
                const response = await axios.get(API_URL + "/instalment_cars", {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });

                this.cars = response.data.cars;
            } catch (err) {

            }
        },
        async getAllApplications() {
            const token = localStorage.getItem("token");
            try {
                const response = await axios.get(API_URL + "/applications", {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });

                this.instalmentIds = response.data.instalments.reduce((arr, item) => {
                    arr.push(item.id);
                    return arr;
                }, [])
            } catch (err) {

            }
        }
    },
    mounted() {
        this.getAllInstalments();
        this.getAllApplications();
    }
}
</script>