<template>
    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-primary">
        <div class="container">
            <router-link class="navbar-brand" to="/dashboard">Installment Cars</router-link>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault"
                aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarsExampleDefault">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#">{{ name }}</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" @click="logout">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</template>

<script>
import axios from 'axios';
import { API_URL } from '@/constant.js';

export default {
    data() {
        return {
            name: ''
        }
    },
    methods: {
        getName() {
            this.name = localStorage.getItem('name');
        },
        async logout() {
            try {
                const token = localStorage.getItem("token");
                const response = await axios.post(API_URL + '/auth/logout', [], {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    }
                });

                localStorage.setItem("justLogout", "1");
                localStorage.removeItem("token");
                this.$router.push({ path: '/' })
            } catch (err) { 
            }
        }
    },
    mounted() {
        this.getName();
    }
}
</script>