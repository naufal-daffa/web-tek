<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Installment extends Model
{
    protected $guarded = [];

    protected $hidden = [
        'created_at',
        'updated_at'
    ];

    public function brand() {
        return $this->belongsTo(Brand::class);
    }

    public function region() {
        return $this->belongsTo(Regional::class);
    }

    public function availableMonths() {
        return $this->hasMany(AvailableMonth::class);
    }
}
