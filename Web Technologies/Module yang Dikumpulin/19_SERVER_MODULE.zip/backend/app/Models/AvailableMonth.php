<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AvailableMonth extends Model
{
    protected $guarded = [];

    protected $hidden = [
        'id',
        'installment_id',
        'nominal',
        'created_at',
        'updated_at'
    ];

    public function installments() {
        return $this->belongsTo(Installment::class);
    }
}
