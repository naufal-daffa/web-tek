<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Validation extends Model
{
    protected $guarded = [];

    protected $hidden = [
        'society_id',
        'created_at',
        'updated_at',
        'validator_id',
    ];

    public function validator() {
        return $this->belongsTo(Validator::class);
    }
}
