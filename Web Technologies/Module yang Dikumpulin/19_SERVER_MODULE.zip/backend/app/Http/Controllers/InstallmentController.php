<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\Installment;
use Illuminate\Http\Request;

class InstallmentController extends Controller
{
    public function getInstalments()
    {
        $installments = Installment::with('brand', 'availableMonths')->get();

        return response()->json([
            'cars' => $installments
        ], 200);
    }

    public function getInstalmentDetail($id)
    {
        $installment = Installment::with('brand', 'availableMonths')->find($id);
        $brand = Brand::find($installment->brand->id);
        $installment->makeHidden('brand_id', 'brand');
        $installment->brand = $brand->name;

        return response()->json([
            'instalment' => $installment
        ], 200);
    }
}
