<?php

namespace App\Http\Controllers;

use App\Models\Validation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ValidationController extends Controller
{
    public function validation(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job' => 'required',
            'job_description' => 'required|min:6',
            'income' => 'required',
            'reason_accepted' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message' => 'Invalid field',
                'errors' => $validator->errors(),
            ], 422);
        }

        Validation::create([
            'job' => $request->job,
            'job_description' => $request->job_description,
            'income' => $request->income,
            'validator_id' => 1, // tembak langsung ID si validator
            'reason_accepted' => $request->reason_accepted,
            'society_id' => auth()->id()
        ]);

        return response()->json([
            'message' => 'Request data validation sent successful'
        ], 200);
    }

    public function getValidations()
    {
        $validations = Validation::with('validator')->where('society_id', auth()->id())->first();

        return response()->json([
            'validation' => $validations
        ], 200);
    }
}
