<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id_card_number' => 'required',
            'password' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message' => 'Invalid field',
                'errors' => $validator->errors(),
            ], 422);
        }

        if (!Auth::attempt($request->only('id_card_number', 'password'))) {
            return response()->json([
                'message' => 'ID Card Number or Password incorrect',
            ], 401);
        }

        $user = Auth::user();
        $user->load('regional');
        $token = $user->createToken('auth_token')->plainTextToken;
        $userArray = $user->toArray();

        $data = array_merge($userArray, ['token' => $token]);

        return response()->json([
            $data
        ], 200);
    }

    public function logout(Request $request)
    {
        if (!$request->bearerToken()) {
            return response()->json([
                'message' => 'Logout success'
            ], 401);
        }

        $user = Auth::user();

        $user->currentAccessToken()->delete();

        return response()->json([
            'message' => 'Logout success',
        ], 200);
    }
}
