<?php

namespace App\Http\Controllers;

use App\Models\AvailableMonth;
use App\Models\Installment;
use App\Models\InstallmentApplySociety;
use App\Models\Validation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ApplicationController extends Controller
{
    public function apply(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'instalment_id' => 'required',
            'months' => 'required',
            'notes' => 'nullable',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message' => 'Invalid field',
                'errors' => $validator->errors(),
            ], 422);
        }

        $availableMonth = AvailableMonth::where('installment_id', $request->instalment_id)->first();

        $validation = Validation::where('society_id', auth()->id())->first();
        if ($validation->status != 'accepted') {
            return response()->json([
                'message' => 'Your data validator must be accepted by
validator before'
            ], 401);
        }

        InstallmentApplySociety::create([
            'notes' => $request->notes,
            'available_month_id' => $availableMonth->id,
            'date' => now(),
            'society_id' => auth()->id(),
            'instalment_id' => $request->instalment_id,
        ]);

        return response()->json([
            'message' => 'Applying for Instalment successful'
        ], 200);
    }
}
