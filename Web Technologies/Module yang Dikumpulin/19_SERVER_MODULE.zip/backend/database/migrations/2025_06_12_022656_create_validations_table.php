<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('validations', function (Blueprint $table) {
            $table->id();
            $table->enum('status', ['accepted', 'declined', 'pending'])->default('pending'); // default accepted ceritanya langsung di acc oleh validator
            $table->string('job');
            $table->string('job_description');
            $table->integer('income');
            $table->text('reason_accepted')->nullable();
            $table->foreignId('validator_id')->constrained('validators');
            $table->foreignId('society_id')->constrained('societies');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('validations');
    }
};
