<?php

namespace Database\Seeders;

use App\Models\AvailableMonth;
use App\Models\Brand;
use App\Models\Installment;
use App\Models\Regional;
use App\Models\Society;
use App\Models\Validator;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();
        Regional::create([
            'province' => 'DKI Jakarta',
            'district' => 'Central Jakarta'
        ]);

        Validator::create([
            'role' => 'officer',
            'name' => 'Bella Habibi'
        ]);

        Validator::create([
            'role' => 'validator',
            'name' => 'Gaman Sihotang'
        ]);

        Society::create([
            'id_card_number' => '20210001',
            'password' => bcrypt('1212112'),
            'name' => 'Bella Habibi',
            'gender' => 'male',
            'address' => 'Ki. Raya Setiabudhi No. 790',
            'born_date' => '2020-02-02',
            'regional_id' => 1,
            // 'validator_id' => 1,
        ]);

        Society::create([
            'id_card_number' => '20210002',
            'password' => bcrypt('1212112'),
            'name' => 'Gaman Sihotang',
            'gender' => 'male',
            'address' => 'Ki. Raya Setiabudhi No. 790',
            'born_date' => '2020-02-02',
            'regional_id' => 1,
            // 'validator_id' => 2,
        ]);

        Brand::create([
            'brand' => 'Toyota',
        ]);

        Brand::create([
            'brand' => 'Yamaha',
        ]);

        Brand::create([
            'brand' => 'BMW',
        ]);

        Installment::create([
            'brand_id' => 1,
            'car' => 'Toyota FT 86',
            'description' => 'xxxx',
            'price' => 96000000
        ]);

        AvailableMonth::create([
            'month' => 12,
            'description' => '12 Months',
            'installment_id' => 1,
            'nominal' => 500000
        ]);
    }
}
