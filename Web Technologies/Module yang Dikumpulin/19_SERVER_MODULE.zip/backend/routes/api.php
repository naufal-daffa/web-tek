<?php

use App\Http\Controllers\ApplicationController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\InstallmentController;
use App\Http\Controllers\ValidationController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::prefix('v1')->group(function () {
    Route::post('login', [AuthController::class, 'login']);
    Route::post('logout', [AuthController::class, 'logout'])->middleware('auth:sanctum');

    Route::middleware('auth:sanctum')->group(function () {
        Route::post('validation', [ValidationController::class, 'validation']);
        Route::get('validations', [ValidationController::class, 'getValidations']);
        Route::get('instalment_cars', [InstallmentController::class, 'getInstalments']);
        Route::get('instalment_cars/{id}', [InstallmentController::class, 'getInstalmentDetail']);
        Route::post('applications', [ApplicationController::class, 'apply']);
    });
});
