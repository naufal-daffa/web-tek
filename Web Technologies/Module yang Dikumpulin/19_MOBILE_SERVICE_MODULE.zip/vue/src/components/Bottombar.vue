<template>
    <nav>
        <div class="flex">
            <router-link to="/carparks">Carpark</router-link>
            <span>|</span>
            <router-link to="/">Events</router-link>
            <span>|</span>
            <router-link to="/weathers">Weather</router-link>
            <span>|</span>
            <router-link to="/settings">Setting</router-link>
        </div>
    </nav>
</template>

<script>
</script>

<style scoped>
nav {
    background: var(--color-background);
    position: fixed;
    bottom: 0;
    padding: 20px 0;
    width: 100%;
}

.flex {
    display: flex;
    justify-content: space-evenly;
}

a {
    color: var(--color-text);
}
</style>