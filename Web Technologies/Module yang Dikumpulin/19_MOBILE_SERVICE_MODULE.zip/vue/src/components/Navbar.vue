<template>
    <nav>
        <div class="container">
            <h3>{{ title }}</h3>
        </div>
    </nav>
</template>

<script>
export default {
    props: {
        title: {
            type: String,
            default: "Page Title"
        }
    },
}
</script>

<style scoped>
nav {
    background: var(--color-background);
    position: fixed;
    top: 0;
    padding: 20px 0;
    width: 100%;
}

h3 {
    text-align: center;
    font-weight: bold;
    color: var(--color-text);
}

.container {  
    display: flex;
    justify-content: center;
    align-items: center;
}
</style>