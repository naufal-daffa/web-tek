<template>
    <Navbar :title="'Carpark Detail Page'" />
    <main>
        <div class="card">
            <div class="card-title">{{ detail.title }}</div>
            <div class="card-subtitle">Available Space : <span id="avlSpace">{{ detail.availableSpaces }}</span></div>
            <div class="card-subtitle">Location : <span id="location">{{ detail.location }}</span></div>
            <div class="card-subtitle">Latitude : <span id="latitude">{{ detail.latitude }}</span></div>
            <div class="card-subtitle">Longtitude : <span id="longtitude">{{ detail.longtitude }}</span></div>
        </div>
    </main>
    <Bottombar />
</template>

<script>
import Navbar from '@/components/Navbar.vue';
import Bottombar from '@/components/Bottombar.vue';

export default {
    components: {
        Navbar,
        Bottombar
    },
    data() {
        return {
            detail: {},
            selectedTheme: localStorage.getItem("theme") || 'system',
        }
    },
    methods: {
        getDetail() {
            let localData = localStorage.getItem('detail');
            this.detail = JSON.parse(localData);
            console.log(this.detail);
        },
        applyTheme(theme) {
            if (theme == 'system') {
                const isDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
                document.documentElement.setAttribute("data-theme", isDark ? 'dark' : 'light');
                localStorage.setItem('theme', 'system');
            } else {
                document.documentElement.setAttribute("data-theme", theme);
                localStorage.setItem('theme', theme);
            }
        }
    },
    mounted() {
        this.getDetail();
    },
    watch: {
        selectedTheme: {
            handler(val) {
                this.applyTheme(val)
            },
            immediate: true,
        }
    }
}

</script>

<style scoped>
main {
    margin-top: 96px;
}

.card {
    background: var(--color-background);
    margin-bottom: 12px;
    padding: 8px;
}

.card-title {
    font-weight: bold;
}
</style>