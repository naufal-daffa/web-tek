<template>
    <Navbar :title="'Carpark Page'" />
    <main>
        <label for="sortBy">Sort by: </label>
        <select v-model="sortBy" @change="getCarpark" id="sortBy">
            <option value="name">Name</option>
            <option value="location">Location</option>
        </select>
        <div v-if="sortedData.length == 0">
            <div class="card" v-for="carpark, index in carparks" @click="storeDetail">
                <div class="card-title" id="title">{{ index }}</div>
                <div class="card-subtitle">Available Space : <span id="avlSpace">{{ carpark.availableSpaces }}</span>
                </div>
                <div class="card-subtitle">Location : <span id="location">{{ carpark.location }}</span></div>
                <div class="card-subtitle">Latitude : <span id="latitude">{{ carpark.latitude }}</span></div>
                <div class="card-subtitle">Longtitude : <span id="longtitude">{{ carpark.longtitude }}</span></div>
            </div>
        </div>
        <div v-else>
            <div class="card" v-for="sortedCarpark, index in sortedData" @click="storeDetail">
                <div class="card-title" id="title">{{ index }}</div>
                <div class="card-subtitle">Available Space : <span id="avlSpace">{{ sortedCarpark.availableSpaces
                        }}</span>
                </div>
                <div class="card-subtitle">Location : <span id="location">{{ sortedCarpark.location }}</span></div>
                <div class="card-subtitle">Latitude : <span id="latitude">{{ sortedCarpark.latitude }}</span></div>
                <div class="card-subtitle">Longtitude : <span id="longtitude">{{ sortedCarpark.longtitude }}</span>
                </div>
            </div>
        </div>
    </main>
    <Bottombar />
</template>

<script>
import Navbar from '@/components/Navbar.vue';
import Bottombar from '@/components/Bottombar.vue';
import { API_URL } from '@/constant.js';
import axios from 'axios';

export default {
    components: {
        Navbar,
        Bottombar
    },
    data() {
        return {
            carparks: [],
            sortedData: [],
            sortBy: '',
            selectedTheme: localStorage.getItem("theme") || 'system',
        }
    },
    methods: {
        async getCarpark() {
            try {
                const response = await axios.get(API_URL + "/carparks.json");

                if (this.sortBy != '') {
                    if (this.sortBy == 'name') {
                        this.sortedData = Object.fromEntries(
                            Object.entries(response.data).sort(([a], [b]) => {
                                a.localeCompare(b);
                            })
                        );

                    } else if (this.sortBy == 'location') {
                        this.sortedData = Object.fromEntries(
                            Object.entries(response.data).sort((a, b) => {
                                a.latitude.toLowerCase().localeCompare(b.latitude.toLowerCase());
                            })
                        );

                        this.sortedData = data;
                    }
                } else {
                    this.carparks = response.data;
                }
            } catch (err) {
            } finally {
                console.log(this.sortedData);
            }
        },
        storeDetail(event) {
            const card = event.currentTarget;

            const title = card.querySelector('#title').textContent;
            const space = card.querySelector('#avlSpace').textContent;
            const location = card.querySelector('#location').textContent;
            const latitude = card.querySelector('#latitude').textContent;
            const longtitude = card.querySelector('#longtitude').textContent;

            const spaceInt = parseInt(space);
            const latitudeInt = parseInt(latitude);
            const longtitudeInt = parseInt(longtitude);

            const data = {
                title: title,
                availableSpace: spaceInt,
                latitude: latitudeInt,
                longtitude: longtitudeInt,
                location: location
            }

            localStorage.setItem('detail', JSON.stringify(data));

            this.$router.push({ path: '/carparks/detail' })
        },
        applyTheme(theme) {
            if (theme == 'system') {
                const isDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
                document.documentElement.setAttribute("data-theme", isDark ? 'dark' : 'light');
                localStorage.setItem('theme', 'system');
            } else {
                document.documentElement.setAttribute("data-theme", theme);
                localStorage.setItem('theme', theme);
            }
        }
    },
    mounted() {
        this.getCarpark();
    },
    watch: {
        selectedTheme: {
            handler(val) {
                this.applyTheme(val)
            },
            immediate: true,
        }
    },
}
</script>

<style scoped>
.card {
    background: var(--color-background);
    margin-bottom: 12px;
    padding: 8px;
}

.card-title {
    font-weight: bold;
}
</style>