<template>
    <Navbar :title="'Settings Page'" />
    <main>
        <p>App Themes :</p>
        <div class="radio-container">
            <div>
                <label for="dark">Dark</label>
                <input type="radio" id="dark" v-model="selectedTheme" value="dark">
            </div>
            <div>
                <label for="light">Light</label>
                <input type="radio" id="light" v-model="selectedTheme" value="light">
            </div>
            <div>
                <label for="system">System</label>
                <input type="radio" id="system" v-model="selectedTheme" value="system">
            </div>
        </div>
    </main>
    <Bottombar />
</template>

<script>
import Navbar from '@/components/Navbar.vue';
import Bottombar from '@/components/Bottombar.vue';

export default {
    components: {
        Navbar,
        Bottombar
    },
    data() {
        return {
            selectedTheme: localStorage.getItem("theme") || 'system',
        }
    },
    methods: {
        applyTheme(theme) {
            if (theme == 'system') {
                const isDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
                document.documentElement.setAttribute("data-theme", isDark ? 'dark' : 'light');
                localStorage.setItem('theme', 'system');
            } else {
                document.documentElement.setAttribute("data-theme", theme);
                localStorage.setItem('theme', theme);
            }
        }
    },
    watch: {
        selectedTheme: {
            handler(val) {
                this.applyTheme(val)
            },
            immediate: true,
        }
    }
}
</script>

<style>
main {
    color: var(--color-text);
}

.radio-container {
    display: flex;
    gap: 12px;
    align-items: center;
    
}
</style>