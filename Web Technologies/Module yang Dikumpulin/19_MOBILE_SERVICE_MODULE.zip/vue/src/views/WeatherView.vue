<template>
    <Navbar :title="'Weather Page'" />
    <main>
        <div class="page-wrapper">
            <div class="weather-container">
                <div class="weather-card" v-for="weather in weathers">
                    <div class="card-date">{{ weather.date }}</div>
                    <img src="@/components/svn-icons/cloudy.svg" class="image-icon" v-if="weather.status == 'Cloudy'">
                    <img src="@/components/svn-icons/rainy.svg" class="image-icon" v-else-if="weather.status == 'Rainy'">
                    <img src="@/components/svn-icons/sunny.svg" class="image-icon" v-else-if="weather.status == 'Sunny'">
                    <div class="card-location">{{ weather.location }}</div>
                    <div class="card-status">{{ weather.status }}</div>
                </div>
            </div>
        </div>
    </main>
    <Bottombar />
</template>
<script>
import Navbar from '@/components/Navbar.vue';
import Bottombar from '@/components/Bottombar.vue';
import CloudySVG from '@/components/svn-icons/cloudy.svg';
import { API_URL } from '@/constant.js';
import axios from 'axios';

export default {
    components: {
        Navbar,
        Bottombar,
        CloudySVG,
    },
    data() {
        return {
            weathers: [],
            selectedTheme: localStorage.getItem("theme") || 'system',
        }
    },
    methods: {
        async getWeather() {
            try {
                const response = await axios.get(API_URL + "/weather.json");

                this.weathers = response.data
            } catch (err) {

            }
        },
        applyTheme(theme) {
            if (theme == 'system') {
                const isDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
                document.documentElement.setAttribute("data-theme", isDark ? 'dark' : 'light');
                localStorage.setItem('theme', 'system');
            } else {
                document.documentElement.setAttribute("data-theme", theme);
                localStorage.setItem('theme', theme);
            }
        }
    },
    mounted() {
        this.getWeather();
    },
    watch: {
        selectedTheme: {
            handler(val) {
                this.applyTheme(val)
            },
            immediate: true,
        }
    }
}
</script>

<style scoped>
.page-wrapper {
    height: 100dvh;
    display: flex;
    justify-content: center;
    align-items: center;
}

.weather-container {
    /* max-width: 100dvh; */
    overflow-x: scroll;
    text-align: center;
    white-space: nowrap;
    display: flex;
}

.weather-card {
    background: var(--color-background);
    word-wrap: normal;
    margin: 0 4em;
    padding: 0 48px;
    padding-top: 50%;
    height: 100dvh;
}

.image-icon {
    width: 128px;
}
</style>