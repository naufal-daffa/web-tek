<template>
    <Navbar :title="'Event Page'" />
    <main>
        <div class="search-query">
            <span>From:</span>
            <input type="date" v-model="start_date">
            <span> - </span>
            <input type="date" v-model="end_date">
        </div>
        <div class="card" v-for="event in events">
            <div class="card-image">
                <img :src="event.image">
            </div>
            <div class="card-title">{{ event.title }}</div>
            <div class="card-date">{{ event.date }}</div>
        </div>
        <h5 v-if="loading">Loading ...</h5>
    </main>
    <Bottombar />
</template>
<script>
import Navbar from '@/components/Navbar.vue';
import Bottombar from '@/components/Bottombar.vue';
import { API_URL } from '@/constant.js';
import axios from 'axios';

export default {
    components: {
        Navbar,
        Bottombar
    },
    data() {
        return {
            events: [],
            showData: 3,
            loading: false,
            scrollTimeout: false,
            start_date: '',
            end_date: '',
            selectedTheme: localStorage.getItem("theme") || 'system',
        }
    },
    methods: {
        async getEvents() {
            this.loading = true;
            try {
                const response = await axios.get(API_URL + "/events.json");

                this.events = response.data.events.slice(0, this.showData);
            } catch (err) {
            } finally {
                this.loading = false;
                setTimeout(() => {
                    this.scrollTimeout = false;
                }, 500);
            }
        },
        applyTheme(theme) {
            if (theme == 'system') {
                const isDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
                document.documentElement.setAttribute("data-theme", isDark ? 'dark' : 'light');
                localStorage.setItem('theme', 'system');
            } else {
                document.documentElement.setAttribute("data-theme", theme);
                localStorage.setItem('theme', theme);
            }
        },
        async getFilteredEvents() {
            this.loading = true;
            try {
                this.events = [];
                const response = await axios.get(API_URL + "/events.json", {
                    params: {
                        beginning_date: this.start_date,
                        ending_date: this.end_date
                    }
                });

                this.events = response.data.events.slice(0, this.showData);
            } catch (err) {
            } finally {
                this.loading = false;
                setTimeout(() => {
                    this.scrollTimeout = false;
                }, 200);
            }
        },

    },
    mounted() {
        this.getEvents();
        document.addEventListener("scroll", () => {
            if (this.scrollTimeout) return;
            if (window.innerHeight + window.scrollY >= document.body.offsetHeight) {
                this.scrollTimeout = true;
                this.showData += 3;
                if (this.start_date && this.end_date) {
                    this.getFilteredEvents();
                } else {
                    this.getEvents();
                }
            }
        })
    },
    watch: {
        start_date: {
            handler() {
                if (this.start_date && this.end_date) {
                    this.getFilteredEvents();
                }
            },
            immediate: true,
        },
        end_date: {
            handler() {
                if (this.start_date && this.end_date) {
                    this.getFilteredEvents();
                }
            },
            immediate: true,
        },
        selectedTheme: {
            handler(val) {
                this.applyTheme(val)
            },
            immediate: true,
        }
    }
}
</script>

<style scoped>
.card {
    background: var(--color-background);
    margin-bottom: 8px;
    padding: 8px;
    border-radius: 4px;
}
</style>