import { createRouter, createWebHistory } from 'vue-router'
import EventView from '@/views/EventView.vue'
import CarParkView from '@/views/CarParkView.vue'
import WeatherView from '@/views/WeatherView.vue'
import SettingView from '@/views/SettingView.vue'
import CarparkDetailView from '@/views/CarparkDetailView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'event',
      component: EventView,
    },
    {
      path: '/settings',
      name: 'setting',
      component: SettingView
    },
    {
      path: '/carparks',
      name: 'carpark',
      component: CarParkView
    },
    {
      path: '/weathers',
      name: 'weather',
      component: WeatherView
    },
    {
      path: '/settings',
      name: 'setting',
      component: SettingView
    },
    {
      path: '/carparks/detail',
      name: 'carparkDetail',
      component: CarparkDetailView
    },
  ],
})

export default router
